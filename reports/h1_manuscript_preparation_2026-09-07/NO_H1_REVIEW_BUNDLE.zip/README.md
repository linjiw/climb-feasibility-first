# Anonymous manuscript and statistical companion

Draft for author/reviewer inspection; not a submission receipt.

`paper.pdf` contains the essential evidence. The CSV files contain paired trained-seed
differences and descriptive learning curves. Run `python verify_statistics.py` with
NumPy and SciPy to reproduce the seed-level means and two-sided 95% Student-t intervals.
The verification tolerance is 1e-12 for this numerical companion only; the underlying
campaign replay compares its complete serialized result exactly.

The allocation contrast is R minus U, with three seed pairs. Its original hard
point target is +0.02 with a positive lower interval bound and a separate all-panel
lower-bound margin of −0.01. H1, when included, is admission on minus off under D,
with five fresh seed pairs; its primary disposition follows the sign of the hard
interval. H1's +0.02 line and all-panel interval are descriptive. Neither analysis
can replace independent policies with clip or trial counts.

Learning curves and allocation attribution are separate from the primary decision.
Positive excess attribution is not the fraction of all samples or a causal waste
estimate. An inconclusive interval establishes neither equivalence nor absence of harm.
The H1 panel is reused from the allocation study.

This companion reproduces statistics from aggregate differences. It does not rerun
training, verify simulator physics, or reproduce the supplementary clip bootstrap.
Licensed motion payloads and model checkpoints are not included. Full reconstruction
requires the declared references, pinned runtime, split/support manifests and source
contracts. No identifying local machine paths are included in this archive.
