"""Recompute paired-seed means/t intervals; does not rerun policies or bootstrap."""
from pathlib import Path
import csv
import json
import numpy as np
from scipy.stats import t
root = Path(__file__).resolve().parent
for path in sorted(root.glob('*_paired.csv')):
    rows = list(csv.DictReader(path.open()))
    expected = json.loads(path.with_name(path.name.replace('_paired.csv', '_expected.json')).read_text())
    n = len(rows)
    for column in ('feasible_hard_difference', 'all_panel_difference'):
        values = np.array([float(row[column]) for row in rows])
        mean = values.mean()
        half = t.ppf(.975, n-1) * values.std(ddof=1) / np.sqrt(n)
        result = expected[column]
        assert result['independent_units'] == n and result['df'] == n-1
        assert np.allclose([mean, mean-half, mean+half], [result['mean'], *result['seed_t_95ci']], atol=1e-12, rtol=0)
        print(path.name, column, 'mean', mean, 't95', [mean-half, mean+half], 'n', n)
    print('Stored registered disposition:', expected['status'])
print('Paired-seed statistics reproduced. This check does not authenticate training or redefine a decision rule.')
